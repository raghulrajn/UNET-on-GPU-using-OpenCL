//////////////////////////////////////////////////////////////////////////////
// OpenCL exercise 6: Prefix sum (Scan)
//////////////////////////////////////////////////////////////////////////////

// includes
#include <stdio.h>

#include <Core/Assert.hpp>
#include <Core/Image.hpp>
#include <Core/Time.hpp>
#include <OpenCL/Device.hpp>
#include <OpenCL/Event.hpp>
#include <OpenCL/Program.hpp>
#include <OpenCL/cl-patched.hpp>

#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>

#include <boost/lexical_cast.hpp>

//////////////////////////////////////////////////////////////////////////////
// CPU implementation
//////////////////////////////////////////////////////////////////////////////
void prefixSumHost(const std::vector<cl_int>& h_input,
                   std::vector<cl_int>& h_output) {
  if (h_input.size() == 0) return;
  cl_int sum = h_input[0];
  h_output[0] = sum;
  for (std::size_t i = 1; i < h_input.size(); i++) {
    sum += h_input[i];
    h_output[i] = sum;
  }
}

//////////////////////////////////////////////////////////////////////////////
// Main function
//////////////////////////////////////////////////////////////////////////////
int main(int argc, char** argv) {
  std::cout << "------------------------------------------------" << std::endl;
  std::cout << "OpenCL Exercise 6: Prefix Sum" << std::endl;
  std::cout << "------------------------------------------------" << std::endl;

  // Create a context
  cl::Context context(CL_DEVICE_TYPE_GPU);
  cl::Event event;
  // Get a device of the context
  int deviceNr = argc < 2 ? 1 : atoi(argv[1]);
  std::cout << "Using device " << deviceNr << " / "
            << context.getInfo<CL_CONTEXT_DEVICES>().size() << std::endl;
  ASSERT(deviceNr > 0);
  ASSERT((size_t)deviceNr <= context.getInfo<CL_CONTEXT_DEVICES>().size());
  cl::Device device = context.getInfo<CL_CONTEXT_DEVICES>()[deviceNr - 1];
  std::vector<cl::Device> devices;
  devices.push_back(device);
  OpenCL::printDeviceInfo(std::cout, device);

  // Create a command queue
  cl::CommandQueue queue(context, device, CL_QUEUE_PROFILING_ENABLE);

  // Declare some values
  std::size_t wgSize = 256;  // Number of work items per work group
  std::size_t count = wgSize * wgSize * wgSize;  // Number of values

  std::size_t size = count * sizeof(cl_int);

  // Load the source code
  extern unsigned char OpenCLExercise6_PrefixSum_cl[];
  extern unsigned int OpenCLExercise6_PrefixSum_cl_len;
  cl::Program program(context,
                      std::string((const char*)OpenCLExercise6_PrefixSum_cl,
                                  OpenCLExercise6_PrefixSum_cl_len));
  // Compile the source code. This is similar to program.build(devices) but will print more detailed error messages
  // This will pass the value of wgSize as a preprocessor constant "WG_SIZE" to the OpenCL C compiler
  OpenCL::buildProgram(program, devices,
                       "-DWG_SIZE=" + boost::lexical_cast<std::string>(wgSize));

  // Allocate space for output data from CPU and GPU on the host
  std::vector<cl_int> h_input(count);
  std::vector<cl_int> h_outputCpu(count);
  std::vector<cl_int> h_temp1(wgSize * wgSize);
  std::vector<cl_int> h_temp2(wgSize);
  std::vector<cl_int> h_outputGpu(count);

  // Initialize memory to 0xff (useful for debugging because otherwise GPU memory will contain information from last execution)
  memset(h_input.data(), 255, size);
  memset(h_temp1.data(), 255, wgSize * wgSize * sizeof(cl_int));
  memset(h_temp2.data(), 255, wgSize * sizeof(cl_int));
  memset(h_outputCpu.data(), 255, size);
  memset(h_outputGpu.data(), 255, size);

  // Allocate space for input and output data on the device
  cl::Buffer d_input(context, CL_MEM_READ_ONLY, count);
  cl::Buffer d_output(context, CL_MEM_READ_WRITE, count);
  cl::Buffer d_temp1_buffer(context, CL_MEM_READ_WRITE, count);

 // The GPU implementation should contain 5 kernel launches:
//1. Launch the prefix sum kernel with 256 * 256 work groups, each with 256 work items. In addition to the normal results, each work group will write one sum into d_temp1 in global memory.
//2. Launch the prefix sum kernel with 256 work groups, each with 256 work items. In addition to the normal results, each work group will write one sum into d_temp2 in global memory.
//3. Launch the prefix sum kernel with 1 work group, with 256 work items. No overall sum is written into global memory.
//4. Launch the block add kernel with 256 work groups, each with 256 work items.
//5. Launch the block add kernel with 256 * 256 work groups, each with 256 work items.

  //////// Generate input data ////////////////////////////////

  for (std::size_t i = 0; i < count; i++) h_input[i] = rand() % 100 - 40;
  // Or: Use consecutive integer numbers as data
  /*
	for (std::size_t i = 0; i < count; i++)
		h_input[i] = i;
	// */

  // Do calculation on the host side
  prefixSumHost(h_input, h_outputCpu);

  // Create kernels
  cl::Kernel prefixSumKernel(program, "prefixSumKernel");

  // Copy input data to device
  queue.enqueueWriteBuffer(d_input, true, 0, count, h_input.data());
  queue.enqueueWriteBuffer(d_output, true, 0, count, h_outputGpu.data());
  queue.enqueueWriteBuffer(d_temp1_buffer, true, 0, count, h_temp1.data());

  // Call the kernels
  cl::LocalSpaceArg htemp_local = cl::Local(sizeof(cl_int) * wgSize*wgSize);

  cl::NDRange global(256 * 256 * 256);
  cl::NDRange local(256);

prefixSumKernel.setArg(0, d_input);
prefixSumKernel.setArg(1, d_output);
prefixSumKernel.setArg(2, cl::Local(256 * sizeof(int)));
prefixSumKernel.setArg(3, d_temp1_buffer);


  prefixSumKernel.setArg<cl::Buffer>(0, d_input);
  prefixSumKernel.setArg<cl::Buffer>(1, d_output);
  prefixSumKernel.setArg(1, htemp_local);

queue.enqueueNDRangeKernel(prefixSumKernel, cl::NullRange, global, local,NULL,
                               &event);

    // Copy output data back to host

  // Copy output data back to host
  queue.enqueueReadBuffer(d_output, true, 0, count, h_outputGpu.data(), NULL, &event);
    queue.finish();
  // Print performance data


  // Check whether results are correct
  std::size_t errorCount = 0;
  for (size_t i = 0; i < count; i = i + 1) {
    if (h_outputCpu[i] != h_outputGpu[i]) {
      if (errorCount < 15)
        std::cout << "Result at " << i << " is incorrect: GPU value is "
                  << h_outputGpu[i] << ", CPU value is " << h_outputCpu[i]
                  << std::endl;
      else if (errorCount == 15)
        std::cout << "..." << std::endl;
      errorCount++;
    }
  }
  if (errorCount != 0) {
    std::cout << "Found " << errorCount << " incorrect results" << std::endl;
    return 1;
  }

  std::cout << "Success" << std::endl;

  return 0;
}
